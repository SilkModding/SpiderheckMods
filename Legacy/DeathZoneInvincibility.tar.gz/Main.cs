﻿using Silk;
using Logger = Silk.Logger;
using HarmonyLib;
using UnityEngine;

namespace DeathZoneInvincibility
{
    [SilkMod("Death Zone Invincibility", new[] { "Abstractmelon" }, "1.0.0", "1.6a", "death-zone-invincibility")]
    public class DeathZoneInvincibility : SilkMod
    {
        public void Initialize()
        {
            Logger.LogInfo("Death Zone Invincibility has loaded!");

            Harmony harmony = new Harmony("com.Abstractmelon.DeathZoneInvincibility");
            harmony.PatchAll();
        }

        public void Update()
        {
        }

        public void Unload()
        {
        }
    }

    [HarmonyPatch(typeof(DeathZone))]
    internal static class DeathZoneInvincibilityPatch
    {
        // Patch the OnTriggerStay2D method to make players invincible in the death zone
        [HarmonyPatch(nameof(DeathZone.OnTriggerStay2D))]
        [HarmonyPrefix]
        public static bool MakePlayersInvincible(Collider2D other)
        {
            // Skip disintegration logic for player objects
            if (other.CompareTag("PlayerRigidbody"))
            {
                
                return false; // Skip the original method
            }

            return true; // Proceed with original logic for non-players
        }
    }
}
