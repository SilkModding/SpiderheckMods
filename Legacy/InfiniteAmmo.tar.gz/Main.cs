﻿using Silk;
using Logger = Silk.Logger;
using HarmonyLib;

namespace InfiniteAmmo
{
    [SilkMod("Infinite Ammo", new[] { "Abstractmelon" }, "1.0.0", "1.6a", "infinite-ammo")]
    public class InfiniteAmmo : SilkMod
    {

        public void Initialize()
        {
            Logger.LogInfo("InfiniteAmmo has loaded!");

            Harmony harmony = new Harmony("com.Abstractmelon.InfiniteAmmo");
            harmony.PatchAll();
        }

        public void Update()
        {
        }

        public void Unload()
        {
        }
    }

    [HarmonyPatch(typeof(Weapon), nameof(Weapon.ammo), MethodType.Getter)]
    internal static class InfiniteAmmoPatch
    {
        public static bool Prefix(ref float __result, Weapon __instance)
        {
            __result = __instance is DeathCube ? __instance.ammo : __instance.maxAmmo;
            return false;
        }
    }
}

