using HarmonyLib;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using UnityEngine;
using UnityEngine.InputSystem;

namespace InfinitePlayers
{
    // Extend the array length for player indexes
    [HarmonyPatch(typeof(LobbyController), MethodType.Constructor)]
    class LobbyController_Patch_Ctor
    {
        // Transpiles
        //    > private PlayerController[] _playerIndexes = new PlayerController[4]
        // to > private PlayerController[] _playerIndexes = new PlayerController[InfinitePlayers.InfinitePlayers.MaxPlayerHardCap];
        [HarmonyTranspiler]
        static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
        {
            CodeInstruction[] array = instructions.ToArray();
            CodeInstruction match = new CodeInstruction(OpCodes.Stfld, AccessTools.Field(typeof(LobbyController), "_playerIndexes"));

            // Search for our match
            int i = 0;
            for (; i < array.Length; i++)
            {
                if (array[i].Is(match.opcode, match.operand)) break;
            }

            // Backtrack to the correct instruction
            if (i != array.Length-1)
            {
                array[i-2] = new CodeInstruction(OpCodes.Ldc_I4, InfinitePlayers.MaxPlayerHardCap); // ldc.i4.4 -> ldc.i4 (InfinitePlayers.InfinitePlayers.MaxPlayerHardCap)
            }

            return array.AsEnumerable();
        }
    }

    // Inject our generated spawn points
    [HarmonyPatch(typeof(LobbyController), nameof(LobbyController.GetSpawnPoints))]
    class LobbyController_Patch_GetSpawnPoints
    {
        [HarmonyPrefix]
        static bool Prefix(LobbyController __instance, ref Transform[] __result)
        {
            // Regenerate spawn points for a new level
            if (SpawnPoints.lastLevel != LevelController.instance.activeLevel || SpawnPoints.spawns[0] == null)
            {
                SpawnPoints.lastLevel = LevelController.instance.activeLevel;
                SpawnPoints.spawns = SpawnPoints.GetDefaultSpawnPoints().ToList();

                SpawnPoints.GenerateSpawnPoints(LobbyController.instance.CountPlayers() - SpawnPoints.spawns.Count);
            }

            __result = SpawnPoints.spawns.ToArray();
            return false;
        }
    }

    // Generate a spawn point for a new player
    [HarmonyPatch(typeof(LobbyController), "OnPlayerJoined")]
    class LobbyController_Patch_OnPlayerJoined
    {
        [HarmonyPrefix]
        static bool Prefix()
        {
            if (SpawnPoints.spawns.Count < PlayerInputManager.instance.playerCount)
            {
                SpawnPoints.GenerateSpawnPoints(1);
            }
            return true;
        }
    }

    // Intercept maxPlayers and reassign to InfinitePlayers.InfinitePlayers.MaxPlayerHardCap
    [HarmonyPatch(typeof(LobbyController), nameof(LobbyController.SetMaxPlayer))]
    class LobbyController_Patch_SetMaxPlayer
    {
        [HarmonyPrefix]
        static bool Prefix(ref int maxPlayers)
        {
            maxPlayers = InfinitePlayers.MaxPlayerHardCap;
            return true;
        }
    }

    // Override the initial max players value
    [HarmonyPatch(typeof(LobbyController), "Start")]
    class LobbyController_Patch_Start
    {
        [HarmonyPostfix]
        static void Postfix(ref LobbyController __instance)
        {
            __instance.SetMaxPlayer(InfinitePlayers.MaxPlayerHardCap);
        }
    }
}