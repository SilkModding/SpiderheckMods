﻿using Silk;
using Logger = Silk.Logger;
using HarmonyLib;

namespace InfinitePlayers
{
    [SilkMod("Infinite Players", new[] { "Abstractmelon", "Senyksia" }, "1.0.0", "1.6a", "infinite-players")]
    public class InfinitePlayers : SilkMod
    {   
        public const int MaxPlayerHardCap = 32;

        // This is called when your mod is loaded
        public void Initialize()
        {   
            // Log that your mod loaded
            Logger.LogInfo("InfinitePlayers has loaded!");

            Harmony harmony = new Harmony("com.Abstractmelon.InfinitePlayers");
            harmony.PatchAll();
        }

        // This is called every frame
        public void Update()
        {
            
        }

        public void Unload()
        {
            
        }
    }
}
